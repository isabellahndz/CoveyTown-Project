import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore/lite';
import { Track } from '../types/MusicArea';

// Firebase configuration
const firebaseConfig = {
  apiKey: 'AIzaSyCX122w0IinUIYCUSBv9uBr_dunuNx_HC4',
  authDomain: 'spring-2023-608.firebaseapp.com',
  projectId: 'spring-2023-608',
  storageBucket: 'spring-2023-608.appspot.com',
  messagingSenderId: '302279763305',
  appId: '1:302279763305:web:608b62c4c3708a7c47c9f8',
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const getTracks = async (collectionName: string) => {
  //const tracks: any[] = [];
  const tracksCol = collection(db, collectionName);
  const colSnapshot = await getDocs(tracksCol);
  const tracks = colSnapshot.docs.map(doc => doc.data());

  return tracks;
};

export const getArtistTracks = async (artist: string) => {
  let collectionName = '';
  switch (artist) {
    case 'Adele':
      collectionName = 'tracks';
      break;
    case 'BTS':
      collectionName = 'bts-tracks';
      break;
    case 'Cardi B':
      collectionName = 'cardi-b-tracks';
      break;
    case 'Doja Cat':
      collectionName = 'doja-cat-tracks';
      break;
    case 'Ed Sheeran':
      collectionName = 'ed-sheeran-tracks';
      break;
    case 'Frank Ocean':
      collectionName = 'frank-ocean-tracks';
      break;
    case 'Harry Styles':
      collectionName = 'harry-styles-tracks';
      break;
    case 'Journey':
      collectionName = 'journey-tracks';
      break;
    case 'Lizzo':
      collectionName = 'lizzo-tracks';
      break;
    case 'Miley Cyrus':
      collectionName = 'miley-cyrus-tracks';
      break;
    default:
      break;
  }
  if (collectionName !== '') {
    const tracks = await getTracks(collectionName);
    return tracks;
  }
  return [];
};

export const getAlbum = async (album: string) => {
  let collectionName = '';
  switch (album) {
    case 'Astroworld':
      collectionName = 'astroworld-album';
      break;
    case 'Blurryface':
      collectionName = 'blurryface-album';
      break;
    case 'Doo-Wops & Hooligans':
      collectionName = 'doo-wops-album';
      break;
    case 'Fine Line':
      collectionName = 'fine-line-album';
      break;
    case 'Future Nostalgia':
      collectionName = 'future-nostalgia-album';
      break;
  }
  if (collectionName !== '') {
    const tracks = await getTracks(collectionName);
    return tracks;
  }
  return [];
};

export const getGenrePlaylist = async (genre: string) => {
  let collectionName = '';
  switch (genre) {
    case 'Alternative':
      collectionName = 'alternative-playlist';
      break;
    case 'Blues':
      collectionName = 'blues-playlist';
      break;
    case 'Country':
      collectionName = 'country-playlist';
      break;
    case 'Disco':
      collectionName = 'disco-playlist';
      break;
    case 'Electro':
      collectionName = 'electro-playlist';
      break;
    case 'Funk':
      collectionName = 'funk-playlist';
      break;
    case 'Gospel':
      collectionName = 'gospel-playlist';
      break;
    case 'Hard-Rock':
      collectionName = 'hard-rock-playlist';
      break;
    case 'Indie':
      collectionName = 'indie-playlist';
      break;
    case 'Pop':
      collectionName = 'pop-playlist';
      break;
    default:
      break;
  }

  if (collectionName !== '') {
    const tracks = await getTracks(collectionName);
    return tracks;
  }
  return [];
};
