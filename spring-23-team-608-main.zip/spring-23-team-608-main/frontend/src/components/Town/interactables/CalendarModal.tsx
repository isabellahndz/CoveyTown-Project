import {
  Button,
  FormControl,
  FormLabel,
  Input,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  useToast,
} from '@chakra-ui/react';
import React, { useCallback, useEffect, useState } from 'react';
import { useInteractable } from '../../../classes/TownController';
import useTownController from '../../../hooks/useTownController';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { nanoid } from 'nanoid';
import { CalendarEvent } from '../../../types/CalendarEvent';
import { SelectMusicModal } from './SelectMusicModal';
import { Track } from '../../../types/MusicArea';

/**
 * The CalendarModal renders the Calendar modal that allows users to create calendar events.
 */
export default function CalendarModal(): JSX.Element {
  const coveyTownController = useTownController();
  const newMusicArea = useInteractable('calendarArea');

  const [creating, setCreating] = useState<boolean>(false);
  const [topic, setTopic] = useState<string>('');
  const [date, setDate] = useState<string>('');
  const [selectIsOpen, setSelectIsOpen] = useState<boolean>(false);
  const [tracks, setTracks] = useState<Track[]>([]);

  const [calendar, setCalendar] = useState(new Date());
  const [musicEvents, setMusicEvents] = useState<CalendarEvent[]>([]);

  const toast = useToast();
  const isOpen = newMusicArea !== undefined;

  const resetCreateForm = () => {
    setTopic('');
    setDate('');
    setTracks([]);
    setCalendar(new Date());
  };

  useEffect(() => {
    if (newMusicArea) {
      coveyTownController.pause();
    } else {
      resetCreateForm();
      coveyTownController.unPause();
    }
  }, [coveyTownController, newMusicArea]);

  const closeModal = useCallback(() => {
    if (newMusicArea) {
      coveyTownController.interactEnd(newMusicArea);
    }
  }, [coveyTownController, newMusicArea]);

  const filterEvents = () => {
    const filteredEvents = coveyTownController.calendarEvents.filter(
      (event: CalendarEvent) =>
        new Date(event.date).toLocaleDateString() === calendar.toLocaleDateString(),
    );
    setMusicEvents(filteredEvents);
  };

  const createMusicEvent = useCallback(async () => {
    if (topic && date) {
      const eventToCreate: CalendarEvent = {
        id: nanoid(),
        topic: topic,
        date: new Date(date).toUTCString(),
        tracks: tracks,
        attendees: [],
      };
      const flag = musicEvents.some((event: CalendarEvent) => event.date === eventToCreate.date);
      if (flag) {
        toast({
          title: 'Event at timeslot already exists',
          description: 'Please select a different datetime',
          status: 'error',
        });
        return;
      }
      try {
        await coveyTownController.createCalendarEvent(eventToCreate);
        toast({
          title: 'Calendar Event Created!',
          status: 'success',
        });
        filterEvents();
        resetCreateForm();
        setCreating(false);
        coveyTownController.unPause();
        closeModal();
      } catch (err) {
        if (err instanceof Error) {
          toast({
            title: 'Unable to create calendar event',
            description: err.toString(),
            status: 'error',
          });
        } else {
          console.trace(err);
          toast({
            title: 'Unexpected Error',
            status: 'error',
          });
        }
      }
    }
  }, [
    topic,
    setTopic,
    date,
    setDate,
    coveyTownController,
    newMusicArea,
    closeModal,
    toast,
    tracks,
    musicEvents,
  ]);

  useEffect(() => {
    filterEvents();
  }, [calendar, coveyTownController.calendarEvents]);

  const format = (d: string) => {
    const input = new Date(d);
    return `${input.getHours()}:${
      input.getMinutes() < 10 ? '0' + input.getMinutes() : input.getMinutes()
    } ${input.getMonth() + 1}/${input.getDate()}/${input.getFullYear()}`;
  };

  const attendEvent = async (event: CalendarEvent) => {
    await coveyTownController.toggleAttendance(event.id);
    filterEvents();
    if (event.attendees.includes(coveyTownController.userID)) {
      toast({
        title: 'You are no longer attending this event!',
        status: 'success',
      });
    } else {
      toast({
        title: 'You are attending this event!',
        status: 'success',
      });
    }
    coveyTownController.unPause();
    closeModal();
  };

  const renderCalendar = () => {
    return (
      <ModalContent>
        <ModalHeader>Music Events Calendar</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <Calendar onChange={setCalendar} value={calendar} />

          <h2 style={{ margin: '10px 0 0 0' }}>
            <strong>Calendar Events on </strong>
            <em>{calendar.toDateString()}</em>
          </h2>
          <hr />
          <ul style={{ listStyleType: 'none' }}>
            {musicEvents.map((event: CalendarEvent) => (
              <li key={event.id}>
                - <strong>{event.topic}</strong> <em>at</em> {format(event.date)}
                <ul style={{ margin: '0 20px' }}>
                  {event.tracks.map((track: Track) => (
                    <li key={track.id}>
                      <em>
                        <strong>{track.name}</strong> by {track.artist_name}
                      </em>
                    </li>
                  ))}
                </ul>
                <div>
                  <strong>Attendees:</strong>
                  <em> {event.attendees.length}</em>
                  <Button colorScheme='blue' size='xs' onClick={() => attendEvent(event)}>
                    RSVP
                  </Button>
                </div>
                <hr />
              </li>
            ))}
          </ul>
        </ModalBody>
        <ModalFooter>
          <Button colorScheme='blue' mr={3} onClick={() => setCreating(true)}>
            Create New Event
          </Button>
        </ModalFooter>
      </ModalContent>
    );
  };

  const renderCreateForm = () => {
    return (
      <ModalContent>
        <ModalHeader>Create a new Music Event in Calendar? </ModalHeader>
        <ModalCloseButton />
        <form
          onSubmit={ev => {
            ev.preventDefault();
            createMusicEvent();
          }}>
          <ModalBody pb={6}>
            <FormControl>
              <FormLabel htmlFor='topic'>Topic of Event</FormLabel>
              <Input
                id='topic'
                placeholder='Topic of this event'
                name='topic'
                value={topic}
                onChange={e => setTopic(e.target.value)}
              />
            </FormControl>
            <FormControl>
              <FormLabel htmlFor='datetime'>Date and Time of Event</FormLabel>
              <Input
                id='datetime-local'
                placeholder='Date + Time of this event'
                size='md'
                type='datetime-local'
                value={date}
                onChange={e => setDate(e.target.value)}
              />
            </FormControl>
            <Button
              style={{ margin: '20px 0 10px' }}
              size='sm'
              colorScheme='blue'
              mr={3}
              onClick={() => setSelectIsOpen(true)}>
              Search for Tracks
            </Button>
            <FormControl>
              <FormLabel style={{ margin: '0' }} htmlFor='tracks'>
                Selected Tracks
              </FormLabel>
              <hr />
              <SelectMusicModal
                isOpen={selectIsOpen}
                onClose={() => {
                  setSelectIsOpen(false);
                }}
                onSelectMusic={(selected: Track[]) => {
                  setTracks(selected);
                }}
              />
              <ul style={{ listStyleType: 'none' }}>
                {tracks.map((track: Track) => {
                  return (
                    <li key={track.id}>
                      - <strong>{track.name}</strong> <em>by</em> {track.artist_name}
                    </li>
                  );
                })}
              </ul>
            </FormControl>
          </ModalBody>
          <ModalFooter>
            <Button
              colorScheme='blue'
              mr={3}
              onClick={createMusicEvent}
              disabled={!(tracks && date && topic)}>
              Create
            </Button>
            <Button
              onClick={() => {
                setCreating(false);
                setTracks([]);
              }}>
              Cancel
            </Button>
          </ModalFooter>
        </form>
      </ModalContent>
    );
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        closeModal();
        coveyTownController.unPause();
      }}>
      <ModalOverlay />
      {creating ? renderCreateForm() : renderCalendar()}
    </Modal>
  );
}
