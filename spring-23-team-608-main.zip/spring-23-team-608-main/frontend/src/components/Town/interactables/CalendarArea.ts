import TownController from '../../../classes/TownController';
import { BoundingBox } from '../../../types/CoveyTownSocket';
import Interactable, { KnownInteractableTypes } from '../Interactable';
import TownGameScene from '../TownGameScene';

export default class CalendarArea extends Interactable {
  private _townController: TownController;

  constructor(scene: TownGameScene) {
    super(scene);
    this._townController = scene.coveyTownController;
    this.setTintFill();
    this.setAlpha(0.3);
  }

  getType(): KnownInteractableTypes {
    return 'calendarArea';
  }

  removedFromScene(): void {}

  addedToScene(): void {
    super.addedToScene();
  }

  public getBoundingBox(): BoundingBox {
    const { x, y, width, height } = this.getBounds();
    return { x, y, width, height };
  }

  private _showInfoBox() {}

  overlap(): void {}

  overlapExit(): void {}
}
