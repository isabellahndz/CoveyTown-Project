import React from 'react';
import MusicAreaController, { MusicAreaEvents } from '../../../classes/MusicAreaController';
import TownController from '../../../classes/TownController';
import TownControllerContext from '../../../contexts/TownControllerContext';
import { ChakraProvider } from '@chakra-ui/react';
import { MusicAreaPlayer } from './MusicAreaPlayer';
import { mock, MockProxy } from 'jest-mock-extended';
import { fireEvent, render, screen } from '@testing-library/react';
import { EventNames } from '@socket.io/component-emitter';
import { act } from 'react-dom/test-utils';

describe('Music Area Player', () => {
  jest.spyOn(window.HTMLMediaElement.prototype, 'pause').mockImplementation(() => {});
  jest.spyOn(window.HTMLMediaElement.prototype, 'play').mockImplementation(jest.fn());

  let musicArea: MusicAreaController;
  type MusicAreaEventName = keyof MusicAreaEvents;
  let addListenerSpy: jest.SpyInstance<
    MusicAreaController,
    [event: MusicAreaEventName, listener: MusicAreaEvents[MusicAreaEventName]]
  >;

  let townController: MockProxy<TownController>;

  beforeEach(() => {
    const mockTrack = {
      id: 'trackId',
      name: 'track',
      artist_name: 'artist',
      image_url: 'test',
      duration_ms: 0,
      preview_url: 'testURL',
    };
    const mockTrack2 = {
      id: 'trackId2',
      name: 'track2',
      artist_name: 'artist2',
      image_url: 'test2',
      duration_ms: 0,
      preview_url: 'testURL2',
    };
    musicArea = new MusicAreaController({
      id: 'test',
      currentTrack: mockTrack,
      tracks: [mockTrack, mockTrack2],
      isPlaying: false,
    });
    townController = mock<TownController>();

    addListenerSpy = jest.spyOn(musicArea, 'addListener');

    render(
      <ChakraProvider>
        <TownControllerContext.Provider value={townController}>
          <MusicAreaPlayer controller={musicArea} />
        </TownControllerContext.Provider>
      </ChakraProvider>,
    );
  });

  /**
   * Retrieve the listener passed to "addListener" for a given eventName
   * @throws Error if the addListener method was not invoked exactly once for the given eventName
   */
  function getSingleListenerAdded<Ev extends EventNames<MusicAreaEvents>>(
    eventName: Ev,
    spy = addListenerSpy,
  ): MusicAreaEvents[Ev] {
    const addedListeners = spy.mock.calls.filter(eachCall => eachCall[0] === eventName);
    if (addedListeners.length !== 1) {
      throw new Error(
        `Expected to find exactly one addListener call for ${eventName} but found ${addedListeners.length}`,
      );
    }
    return addedListeners[0][1] as unknown as MusicAreaEvents[Ev];
  }

  describe('Display information about Music Area', () => {
    it('Contains a header', () => {
      const header = screen.getByText('Music Area: test');
      expect(header).toBeInTheDocument();
    });

    it('Displays information about current track', () => {
      const trackName = screen.getByText('track');
      const trackArtist = screen.getByText('artist');
      expect(trackName).toBeInTheDocument();
      expect(trackArtist).toBeInTheDocument();
    });
  });

  describe('Controls buttons', () => {
    it('Adds a playbackChange listener when the play button is pressed', () => {
      const playButton = screen.getByTestId('play-pause-button');
      act(() => {
        fireEvent.click(playButton);
        expect(getSingleListenerAdded('playbackChange')).not.toThrowError();
      });
    });
    it('Adds a playbackChange listener when the pause button is pressed', () => {
      const playButton = screen.getByTestId('play-pause-button');
      act(() => {
        fireEvent.click(playButton);
        fireEvent.click(playButton);
        expect(getSingleListenerAdded('playbackChange')).not.toThrowError();
      });
    });
    it('Adds a trackChange listener when the next button is pressed', () => {
      const nextButton = screen.getByTestId('next-button');
      act(() => {
        fireEvent.click(nextButton);
        expect(getSingleListenerAdded('trackChange')).not.toThrowError();
      });
    });
    it('Adds a trackChange listener when the previous button is pressed', () => {
      const previousButton = screen.getByTestId('previous-button');
      act(() => {
        fireEvent.click(previousButton);
        expect(getSingleListenerAdded('trackChange')).not.toThrowError();
      });
    });
  });
});
