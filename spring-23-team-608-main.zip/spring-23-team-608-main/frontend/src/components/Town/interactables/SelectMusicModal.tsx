import {
  Button,
  FormControl,
  FormLabel,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Select,
} from '@chakra-ui/react';
import React, { useState } from 'react';
import { getArtistTracks, getAlbum, getGenrePlaylist } from '../../../services/Firebase';

type SelectMusicModalProps = {
  isOpen: boolean;
  onClose: () => void;
  onSelectMusic: (item: any) => void;
};

export function SelectMusicModal({ isOpen, onClose, onSelectMusic }: SelectMusicModalProps) {
  const [selectedOption, setSelectedOption] = useState('artist');
  const [searchInput, setSearchInput] = useState('');

  const artists = [
    'Adele',
    'BTS',
    'Cardi B',
    'Doja Cat',
    'Ed Sheeran',
    'Frank Ocean',
    'Harry Styles',
    'Journey',
    'Lizzo',
    'Miley Cyrus',
  ];

  const albums = [
    'Astroworld',
    'Blurryface',
    'Doo-Wops & Hooligans',
    'Fine Line',
    'Future Nostalgia',
  ];

  const genres = [
    'Alternative',
    'Blues',
    'Country',
    'Disco',
    'Electro',
    'Funk',
    'Gospel',
    'Hard-Rock',
    'Indie',
    'Pop',
  ];

  const handleSelectOption = (event: any) => {
    setSelectedOption(event.target.value);
  };

  const handleSearchInput = (event: any) => {
    setSearchInput(event.target.value);
  };

  const handleSubmit = async () => {
    if (selectedOption === 'artist') {
      const tracks = await getArtistTracks(searchInput);
      onSelectMusic(tracks);
    } else if (selectedOption === 'album') {
      const tracks = await getAlbum(searchInput);
      onSelectMusic(tracks);
    } else if (selectedOption === 'genre') {
      const tracks = await getGenrePlaylist(searchInput);
      onSelectMusic(tracks);
    }
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        onClose();
      }}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Select Music</ModalHeader>
        <ModalCloseButton />
        <form
          onSubmit={ev => {
            ev.preventDefault();
            handleSubmit();
          }}>
          <ModalBody pb={6}>
            <FormControl>
              <FormLabel htmlFor='search'>Search by {selectedOption}</FormLabel>
              <Select id='search' name='search' value={searchInput} onChange={handleSearchInput}>
                {/* Add options based on selectedOption */}
                {selectedOption === 'artist' &&
                  artists.map(artist => (
                    <option key={artist} value={artist}>
                      {artist}
                    </option>
                  ))}
                {selectedOption === 'album' &&
                  albums.map(album => (
                    <option key={album} value={album}>
                      {album}
                    </option>
                  ))}
                {selectedOption === 'genre' &&
                  genres.map(genre => (
                    <option key={genre} value={genre}>
                      {genre}
                    </option>
                  ))}
              </Select>
            </FormControl>
            <FormControl mt={4}>
              <FormLabel htmlFor='options'>Options</FormLabel>
              <Select
                id='options'
                name='options'
                value={selectedOption}
                onChange={handleSelectOption}>
                <option value='artist'>Artist</option>
                <option value='album'>Album</option>
                <option value='genre'>Genre</option>
              </Select>
            </FormControl>
          </ModalBody>
          <ModalFooter>
            <Button colorScheme='green' mr={3} onClick={handleSubmit}>
              Select
            </Button>
            <Button onClick={onClose}>Cancel</Button>
          </ModalFooter>
        </form>
      </ModalContent>
    </Modal>
  );
}
