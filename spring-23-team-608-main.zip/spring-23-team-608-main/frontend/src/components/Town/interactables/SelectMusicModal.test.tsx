import React from 'react';
import { render, fireEvent, screen, act } from '@testing-library/react';
import '@testing-library/jest-dom';
import { SelectMusicModal } from './SelectMusicModal';
import { getAlbum, getArtistTracks, getGenrePlaylist } from '../../../services/Firebase';

jest.mock('../../../services/Firebase', () => ({
  getAlbum: jest.fn(),
  getArtistTracks: jest.fn(),
  getGenrePlaylist: jest.fn(),
}));

describe('SelectMusicModal', () => {
  it('renders correctly', () => {
    const onClose = jest.fn();
    const onSelectMusic = jest.fn();

    const { getByText } = render(
      <SelectMusicModal isOpen={true} onClose={onClose} onSelectMusic={onSelectMusic} />,
    );

    expect(getByText('Select Music')).toBeInTheDocument();
  });

  it('changes the selected option and search input', async () => {
    const onClose = jest.fn();
    const onSelectMusic = jest.fn();

    render(<SelectMusicModal isOpen={true} onClose={onClose} onSelectMusic={onSelectMusic} />);

    const selectOptions = screen.getByLabelText('Options');
    const searchInput = screen.getByLabelText(`Search by artist`);

    fireEvent.change(selectOptions, { target: { value: 'album' } });
    fireEvent.change(searchInput, { target: { value: 'Astroworld' } });

    expect(selectOptions).toHaveValue('album');
    expect(searchInput).toHaveValue('Astroworld');
  });
  it('calls getArtistTracks when artist option is selected and button is clicked', async () => {
    const mockTracks = [{ id: '1', name: 'Test Track', artist: 'Test Artist' }];

    (getArtistTracks as jest.Mock).mockResolvedValue(mockTracks);

    await act(() => new Promise(resolve => setTimeout(resolve, 0)));

    expect(getArtistTracks).toHaveBeenCalledTimes(1);
    expect(getArtistTracks).toHaveBeenCalledWith('Adele');
  });

  it('calls getAlbum when album option is selected and button is clicked', async () => {
    const onClose = jest.fn();
    const onSelectMusic = jest.fn();
    const mockTracks = [{ id: '1', name: 'Test Track', artist: 'Test Artist' }];

    (getAlbum as jest.Mock).mockResolvedValue(mockTracks);

    render(<SelectMusicModal isOpen={true} onClose={onClose} onSelectMusic={onSelectMusic} />);

    fireEvent.change(screen.getByLabelText('Options'), { target: { value: 'album' } });
    fireEvent.change(screen.getByLabelText('Search by album'), { target: { value: 'Astroworld' } });
    fireEvent.click(screen.getByText('Select'));

    await act(() => new Promise(resolve => setTimeout(resolve, 0)));

    expect(getAlbum).toHaveBeenCalledTimes(1);
    expect(getAlbum).toHaveBeenCalledWith('Astroworld');
  });

  it('calls getGenrePlaylist when genre option is selected and button is clicked', async () => {
    const onClose = jest.fn();
    const onSelectMusic = jest.fn();
    const mockTracks = [{ id: '1', name: 'Test Track', artist: 'Test Artist' }];

    (getGenrePlaylist as jest.Mock).mockResolvedValue(mockTracks);

    render(<SelectMusicModal isOpen={true} onClose={onClose} onSelectMusic={onSelectMusic} />);

    fireEvent.change(screen.getByLabelText('Options'), { target: { value: 'genre' } });
    fireEvent.change(screen.getByLabelText('Search by genre'), {
      target: { value: 'Alternative' },
    });
    fireEvent.click(screen.getByText('Select'));

    await act(() => new Promise(resolve => setTimeout(resolve, 0)));

    expect(getGenrePlaylist).toHaveBeenCalledTimes(1);
    expect(getGenrePlaylist).toHaveBeenCalledWith('Alternative');
  });
});
