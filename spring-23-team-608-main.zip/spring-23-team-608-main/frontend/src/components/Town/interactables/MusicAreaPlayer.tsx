import MusicAreaController from '../../../classes/MusicAreaController';
import React, { useState, useEffect, useRef } from 'react';
import useTownController from '../../../hooks/useTownController';
import { Container } from '@chakra-ui/react';
import DisplayTrack from '../../MusicPlayer/DisplayTrack';
import Controls from '../../MusicPlayer/Controls';
import { useInteractable, useMusicAreaController } from '../../../classes/TownController';
import MusicAreaInteractable from './MusicArea';
import { Track } from '../../../types/MusicArea';
import { SelectMusicModal } from './SelectMusicModal';

/**
 * The MusicAreaPlayer component renders a MusicArea's music player.
 * The MusicAreaPlayer subscribes to the MusicAreaController's events and responds to
 * playbackChange events by pausing (or resuming) the song playback as appropriate.
 * @param props: A single property 'controller', which is the MusicAreaController corresponding to the current music area.
 */
export function MusicAreaPlayer({ controller }: { controller: MusicAreaController }): JSX.Element {
  const [isPlaying, setPlaying] = useState<boolean>(controller.isPlaying);
  const [trackIndex, setTrackIndex] = useState<number>(0);
  const [currentTrack, setCurrentTrack] = useState(controller.currentTrack);
  const townController = useTownController();
  const audioRef = useRef();

  const onPlay = () => {
    controller.isPlaying = true;
    townController.emitMusicAreaUpdate(controller);
    setPlaying(true);
  };

  const onPause = () => {
    controller.isPlaying = false;
    townController.emitMusicAreaUpdate(controller);
    setPlaying(false);
  };

  const handleNext = () => {
    if (controller.tracks) {
      if (trackIndex >= controller.tracks.length - 1) {
        setTrackIndex(0);
        controller.currentTrack = controller.tracks[0];
        setCurrentTrack(controller.currentTrack);
      } else {
        setTrackIndex((prev: number) => prev + 1);
        controller.currentTrack = controller.tracks[trackIndex];
        setCurrentTrack(controller.currentTrack);
      }
      onPause();
    }
  };

  const handlePrevious = () => {
    if (controller.tracks) {
      if (trackIndex === 0) {
        const lastTrackIndex = controller.tracks.length - 1;
        setTrackIndex(lastTrackIndex);
        controller.currentTrack = controller.tracks[lastTrackIndex];
        townController.emitMusicAreaUpdate(controller);
        setCurrentTrack(controller.currentTrack);
      } else {
        setTrackIndex((prev: number) => prev - 1);
        controller.currentTrack = controller.tracks[trackIndex];
        townController.emitMusicAreaUpdate(controller);
        setCurrentTrack(controller.currentTrack);
      }
      onPlay();
    }
  };

  useEffect(() => {
    setCurrentTrack(controller.currentTrack);

    controller.addListener('playbackChange', setPlaying);
    controller.addListener('trackChange', setCurrentTrack);
    return () => {
      controller.removeListener('playbackChange', setPlaying);
      controller.removeListener('trackChange', setCurrentTrack);
    };
  }, [controller]);

  return (
    <Container className='participant-wrapper'>
      Music Area: {controller.id}
      <div>
        {currentTrack && (
          <DisplayTrack currentTrack={currentTrack} audioRef={audioRef} handleNext={handleNext} />
        )}
        <Controls
          audioRef={audioRef}
          onPlay={onPlay}
          onPause={onPause}
          handleNext={handleNext}
          handlePrevious={handlePrevious}
          defaultIsPlaying={isPlaying}
          controller={controller}
        />
      </div>
    </Container>
  );
}

/**
 * The MusicArea monitors the player's interaction with a MusicArea on the map: displaying either
 * a popup to set the music for a music area, or if the music is set, a music player.
 *
 * @param props: this music area interactable that is being interacted with
 */
export function MusicArea({ musicArea }: { musicArea: MusicAreaInteractable }): JSX.Element {
  const townController = useTownController();
  const musicAreaController = useMusicAreaController(musicArea.name);
  const [selectIsOpen, setSelectIsOpen] = useState(musicAreaController.currentTrack === undefined);
  const [musicAreaCurrentTrack, setMusicAreaCurrentTrack] = useState(
    musicAreaController.currentTrack,
  );

  const onSelectMusic = (tracks: Track[]) => {
    musicAreaController.tracks = tracks;
    musicAreaController.currentTrack = tracks[0];
    setMusicAreaCurrentTrack(musicAreaController.currentTrack);
    townController.emitMusicAreaUpdate(musicAreaController);
  };

  if (!musicAreaCurrentTrack) {
    return (
      <SelectMusicModal
        isOpen={selectIsOpen}
        onClose={() => {
          setSelectIsOpen(false);
          //townController.interactEnd(musicArea);
        }}
        onSelectMusic={onSelectMusic}
      />
    );
  }
  return (
    <>
      <MusicAreaPlayer controller={musicAreaController} />
    </>
  );
}

/**
 * The MusicAreaWrapper is suitable to be *always* rendered inside of a town, and
 * will activate only if the player begins interacting with a viewing area.
 */
export default function MusicAreaWrapper(): JSX.Element {
  const musicArea = useInteractable<MusicAreaInteractable>('musicArea');

  if (musicArea) {
    return (
      <Container className='participant-wrapper'>
        <MusicArea musicArea={musicArea} />
      </Container>
    );
  }
  return <></>;
}
