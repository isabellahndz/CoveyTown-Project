import {
  Button,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  useToast,
  OrderedList,
  ListItem,
} from '@chakra-ui/react';
import { nanoid } from 'nanoid';
import React, { useCallback, useEffect, useState } from 'react';
import { useInteractable } from '../../../classes/TownController';
import useTownController from '../../../hooks/useTownController';
import { Track } from '../../../types/CoveyTownSocket';
import { LeaderboardItem } from '../../../types/LeaderboardItem';

export default function LeaderboardModal(): JSX.Element {
  const coveyTownController = useTownController();
  const newLeaderboard = useInteractable('leaderboardArea');
  const curPlayerId = coveyTownController.ourPlayer.id;
  const [artistShowing, setArtistShowing] = useState<boolean>(false);
  const [leaderboard, setLeaderboard] = useState<LeaderboardItem[]>(
    coveyTownController.leaderboard,
  );
  const isOpen = newLeaderboard !== undefined;

  const toast = useToast();

  const addItem = useCallback(
    async (item: LeaderboardItem) => {
      try {
        await coveyTownController.addLeaderboardItem(item);
        setLeaderboard([...coveyTownController.leaderboard]);
      } catch (err) {
        if (err instanceof Error) {
          toast({
            title: 'Unable to add item',
            description: err.toString(),
            status: 'error',
          });
        } else {
          console.trace(err);
          toast({
            title: 'Unexpected Error',
            status: 'error',
          });
        }
      }
    },
    [setLeaderboard, coveyTownController, toast],
  );

  const addTracks = async (tracks: Track[]) => {
    for (const trackIndex in tracks) {
      const track = tracks[trackIndex];
      if (
        !coveyTownController.leaderboard
          .filter(item => item.type === false)
          .map(item => item.id)
          .includes(track.id)
      ) {
        await addItem({ id: track.id, type: false, name: track.name, votes: 0 });
      }
      if (
        !coveyTownController.leaderboard
          .filter(item => item.type === true)
          .map(item => item.name)
          .includes(track.artist_name)
      ) {
        await addItem({ id: nanoid(), type: true, name: track.artist_name, votes: 0 });
      }
    }
  };

  useEffect(() => {
    if (newLeaderboard) {
      for (let i = 0; i < coveyTownController.musicAreas.length; i++) {
        const tracks = coveyTownController.musicAreas[i].tracks;
        if (tracks) {
          addTracks(tracks);
        }
      }
      coveyTownController.pause();
    } else {
      coveyTownController.unPause();
    }
  }, [coveyTownController, newLeaderboard, addItem]);

  const closeModal = useCallback(() => {
    if (newLeaderboard) {
      coveyTownController.interactEnd(newLeaderboard);
    }
  }, [coveyTownController, newLeaderboard]);

  const addVote = useCallback(
    async (id: string) => {
      if (newLeaderboard) {
        try {
          if (
            coveyTownController.playersWhoVoted[id] &&
            coveyTownController.playersWhoVoted[id].includes(curPlayerId)
          ) {
            toast({
              title: `Can't vote for an item more than once`,
              status: 'error',
            });
          } else {
            coveyTownController.addPlayerWhoVoted(id, curPlayerId);
            await coveyTownController.addLeaderboardVote(id);
            toast({
              title: 'Voted!',
              status: 'success',
            });
            setLeaderboard([...coveyTownController.leaderboard]);
          }
        } catch (err) {
          if (err instanceof Error) {
            toast({
              title: 'Unable to vote',
              description: err.toString(),
              status: 'error',
            });
          } else {
            console.trace(err);
            toast({
              title: 'Unexpected Error',
              status: 'error',
            });
          }
        }
      }
    },
    [curPlayerId, newLeaderboard, coveyTownController, toast],
  );

  class LeaderboardItemUI extends React.Component<{ id: string; name: string; votes: number }> {
    id: string;

    name: string;

    votes: number;

    constructor(props: { id: string; name: string; votes: number }) {
      super(props);
      this.id = props.id;
      this.name = props.name;
      this.votes = props.votes;
    }

    render() {
      return (
        <ListItem listStyleType='none' borderRadius='md' bg='#ccccff' key={this.id}>
          <Button colorScheme='blue' ml={3} key={this.id} onClick={() => addVote(this.id)}>
            Vote
          </Button>
          {' ' + this.name}
          <p>
            <strong>{'Votes: ' + this.votes}</strong>
          </p>
        </ListItem>
      );
    }
  }

  const showTrackLeaderboard = () => {
    return (
      <ModalContent>
        <ModalHeader>Music Track Leaderboard</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <OrderedList>
            {leaderboard
              .filter(i => i.type === false)
              .sort((a, b) => {
                return b.votes - a.votes;
              })
              .map(item => {
                const leaderboardItemProps = {
                  id: item.id,
                  name: item.name,
                  votes: item.votes,
                };
                return <LeaderboardItemUI key={item.id} {...leaderboardItemProps} />;
              })}
          </OrderedList>
        </ModalBody>

        <ModalFooter>
          <Button colorScheme='blue' mr={3} onClick={() => setArtistShowing(true)}>
            View Artist Leaderboard
          </Button>
        </ModalFooter>
      </ModalContent>
    );
  };

  const showArtistLeaderboard = () => {
    return (
      <ModalContent>
        <ModalHeader>Music Artist Leaderboard </ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <OrderedList>
            {leaderboard
              .filter(i => i.type === true)
              .sort((a, b) => {
                return b.votes - a.votes;
              })
              .map(item => {
                const leaderboardItemProps = {
                  id: item.id,
                  name: item.name,
                  votes: item.votes,
                };
                return <LeaderboardItemUI key={item.id} {...leaderboardItemProps} />;
              })}
          </OrderedList>
        </ModalBody>

        <ModalFooter>
          <Button colorScheme='blue' mr={3} onClick={() => setArtistShowing(false)}>
            View Track Leaderboard
          </Button>
        </ModalFooter>
      </ModalContent>
    );
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        closeModal();
        coveyTownController.unPause();
      }}>
      <ModalOverlay />
      {artistShowing ? showArtistLeaderboard() : showTrackLeaderboard()}
    </Modal>
  );
}
