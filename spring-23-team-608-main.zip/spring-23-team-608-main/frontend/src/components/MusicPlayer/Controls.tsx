import React, { useEffect, useState } from 'react';
import MusicAreaController from '../../classes/MusicAreaController';
import Next from '../icons/Next';
import Pause from '../icons/Pause';
import Play from '../icons/Play';
import Previous from '../icons/Previous';

type ControlsProps = {
  audioRef: any;
  onPlay: () => void;
  onPause: () => void;
  handleNext: () => void;
  handlePrevious: () => void;
  defaultIsPlaying: boolean;
  controller?: MusicAreaController;
};

export default function Controls({
  audioRef,
  onPlay,
  onPause,
  handleNext,
  handlePrevious,
  defaultIsPlaying,
  controller,
}: ControlsProps): JSX.Element {
  const [isPlaying, setIsPlaying] = useState<boolean>(defaultIsPlaying);

  useEffect(() => {
    if (isPlaying) {
      if (audioRef.current) {
        audioRef.current?.play();
      }
    } else {
      if (audioRef.current) {
        audioRef.current?.pause();
      }
    }
  }, [isPlaying, setIsPlaying, audioRef]);

  useEffect(() => {
    if (controller) {
      setIsPlaying(controller.isPlaying);
    }
  }, [controller, controller?.isPlaying]);

  const togglePlayPause = () => {
    if (isPlaying) {
      onPause();
    } else {
      onPlay();
    }
    setIsPlaying(prev => !prev);
  };

  return (
    <div>
      <div className='controls-container'>
        <button data-testid='previous-button' onClick={handlePrevious}>
          <Previous />
        </button>

        <button data-testid='play-pause-button' onClick={togglePlayPause}>
          {isPlaying ? <Pause /> : <Play />}
        </button>

        <button data-testid='next-button' onClick={handleNext}>
          <Next />
        </button>
      </div>
    </div>
  );
}
