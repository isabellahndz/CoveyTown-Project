import { Track } from '../../types/MusicArea';
import React, { useEffect } from 'react';

type DisplayTrackProps = {
  audioRef: any;
  currentTrack: Track;
  handleNext: () => void;
};

export default function DisplayTrack({
  audioRef,
  currentTrack,
  handleNext,
}: DisplayTrackProps): JSX.Element {
  useEffect(() => {
    audioRef.current.volume = 0.1;
  }, []);

  return (
    <div>
      <audio src={currentTrack.preview_url} ref={audioRef} onEnded={handleNext} />
      <div>
        <div>
          {currentTrack.image_url ? (
            <img src={currentTrack.image_url} alt={currentTrack.name + ' image'} />
          ) : (
            <div />
          )}
        </div>
        <div>
          <h1>{currentTrack.name}</h1>
          <h2>{currentTrack.artist_name || ''}</h2>
        </div>
      </div>
    </div>
  );
}
