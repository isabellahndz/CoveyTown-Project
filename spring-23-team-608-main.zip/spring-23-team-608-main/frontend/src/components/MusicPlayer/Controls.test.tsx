import { ChakraProvider } from '@chakra-ui/react';
import Controls from './Controls';
import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
describe('Controls', () => {
  let play = 0;
  let pause = 0;
  let next = 0;
  let previous = 0;
  const ref = {
    current: {
      play: () => {},
      pause: () => {},
    },
  };
  const onPlay = () => {
    play++;
  };
  const onPause = () => {
    pause++;
  };
  const handleNext = () => {
    next++;
  };
  const handlePrevious = () => {
    previous++;
  };

  beforeEach(() => {
    play = 0;
    pause = 0;
    next = 0;
    previous = 0;

    render(
      <ChakraProvider>
        <React.StrictMode>
          <Controls
            audioRef={ref}
            onPlay={onPlay}
            onPause={onPause}
            handleNext={handleNext}
            handlePrevious={handlePrevious}
            defaultIsPlaying={false}
          />
        </React.StrictMode>
      </ChakraProvider>,
    );
  });

  it('Calls a function when previous button is pressed', () => {
    const previousButton = screen.getByTestId('previous-button');
    fireEvent.click(previousButton);
    expect(previous).toBe(1);
  });

  it('Calls a function when next button is pressed', () => {
    const nextButton = screen.getByTestId('next-button');
    fireEvent.click(nextButton);
    expect(next).toBe(1);
  });

  describe('Pause/Play action', () => {
    it('Calls a function when play button is pressed.', () => {
      const playButton = screen.getByTestId('play-pause-button');
      fireEvent.click(playButton);
      expect(play).toBe(1);
    });
    it('Toggles pause/play button', () => {
      const playButton = screen.getByTestId('play-pause-button');
      fireEvent.click(playButton);
      const pauseButton = screen.queryByTestId('pause');
      expect(pauseButton).not.toBeNull();
      expect(pauseButton).toBeInTheDocument();
    });
    it('Calls a function when pause button is pressed', () => {
      const playButton = screen.getByTestId('play-pause-button');
      fireEvent.click(playButton);
      const pauseButton = screen.getByTestId('pause');
      fireEvent.click(pauseButton);
      expect(pause).toBe(1);
    });
  });
});
