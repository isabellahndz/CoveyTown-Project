import { ChakraProvider } from '@chakra-ui/react';
import DisplayTrack from './DisplayTrack';
import React from 'react';
import { render, screen } from '@testing-library/react';

describe('DisplayTrack', () => {
  const ref = {
    current: {
      play: () => {},
      pause: () => {},
    },
  };

  const currentTrack = {
    id: '1',
    name: 'Track 1',
    artist_name: 'artist',
    image_url: 'image1URL',
    duration_ms: 0,
    preview_urL: 'url',
  };

  beforeEach(() => {
    render(
      <ChakraProvider>
        <React.StrictMode>
          <DisplayTrack audioRef={ref} currentTrack={currentTrack} handleNext={() => {}} />
        </React.StrictMode>
      </ChakraProvider>,
    );
  });

  describe('Displays track information', () => {
    it('Displays track name', () => {
      const trackName = screen.queryByText('Track 1');
      expect(trackName).not.toBeNull();
      expect(trackName).toBeInTheDocument();
    });
    it('Displays track artist name', () => {
      const artist = screen.queryByText('artist');
      expect(artist).not.toBeNull();
      expect(artist).toBeInTheDocument();
    });
  });
});
