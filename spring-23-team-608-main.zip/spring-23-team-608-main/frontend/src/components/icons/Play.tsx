import React from 'react';

export default function Play() {
  return (
    <svg
      width='24'
      height='24'
      viewBox='0 0 24 24'
      fill='none'
      xmlns='http://www.w3.org/2000/svg'
      data-testid='play'>
      <g>
        <path d='M8 5V19L19 12L8 5Z' fill='black' />
      </g>
      <defs>
        <clipPath id='clip0_463_8134'>
          <rect width='24' height='24' fill='white' />
        </clipPath>
      </defs>
    </svg>
  );
}
