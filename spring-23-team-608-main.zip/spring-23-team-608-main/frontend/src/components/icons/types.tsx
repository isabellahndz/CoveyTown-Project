type IconProps = {
  onClick: () => void;
};

export default IconProps;
