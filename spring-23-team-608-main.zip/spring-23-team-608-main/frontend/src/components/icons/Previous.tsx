import React from 'react';

export default function Previous() {
  return (
    <svg width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'>
      <g>
        <path d='M6 6H8V18H6V6ZM9.5 12L18 18V6L9.5 12Z' fill='black' />
      </g>
      <defs>
        <clipPath id='clip0_463_8143'>
          <rect width='24' height='24' fill='white' />
        </clipPath>
      </defs>
    </svg>
  );
}
