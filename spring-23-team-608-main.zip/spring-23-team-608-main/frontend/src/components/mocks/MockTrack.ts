import { Track } from '../../types/MusicArea';

export const mockTrack1: Track = {
  id: '0nJW01T7XtvILxQgC5J7Wh',
  name: 'When I Was Your Man',
  artist_name: 'Bruno Mars',
  image_url: 'https://i.scdn.co/image/ab67616d0000b273926f43e7cce571e62720fd46',
  duration_ms: 213826,
  preview_url:
    'https://p.scdn.co/mp3-preview/159fc05584217baa99581c4821f52d04670db6b2?cid=bd1996f1d5e9434c964e662b8f8d2569',
};

export const mockTrack2: Track = {
  id: '0nJW01T7XtvILxQgC5J7Wh',
  name: 'Locked out of Heaven',
  artist_name: 'Bruno Mars',
  image_url: 'https://i.scdn.co/image/ab67616d0000b273926f43e7cce571e62720fd46',
  duration_ms: 233478,
  preview_url:
    'https://p.scdn.co/mp3-preview/5a0318e6c43964786d22b9431af35490e96cff3d?cid=bd1996f1d5e9434c964e662b8f8d2569',
};

export const mockTrack3: Track = {
  id: '7BqBn9nzAq8spo5e7cZ0dJ',
  name: 'Just the Way You Are',
  artist_name: 'Bruno Mars',
  image_url: 'https://i.scdn.co/image/ab67616d0000b273f6b55ca93bd33211227b502b',
  duration_ms: 220734,
  preview_url:
    'https://p.scdn.co/mp3-preview/6d1a901b10c7dc609d4c8628006b04bc6e672be8?cid=bd1996f1d5e9434c964e662b8f8d2569',
};

export const mockTrack4: Track = {
  id: '161DnLWsx1i3u1JT05lzqU',
  name: 'Talking to the Moon',
  artist_name: 'Bruno Mars',
  image_url: 'https://i.scdn.co/image/ab67616d0000b273f6b55ca93bd33211227b502b',
  duration_ms: 217866,
  preview_url:
    'https://p.scdn.co/mp3-preview/6feba1b412530ab0d9dd1f849180f039831acc42?cid=bd1996f1d5e9434c964e662b8f8d2569',
};

export const mockTrack5: Track = {
  id: '0nJW01T7XtvILxQgC5J7Wh',
  name: "That's What I Like",
  artist_name: 'Bruno Mars',
  image_url: 'https://i.scdn.co/image/ab67616d0000b273232711f7d66a1e19e89e28c5',
  duration_ms: 206693,
  preview_url:
    'https://p.scdn.co/mp3-preview/93046e987d8c5bfdbeea2768ac1a8ecea17bd7e0?cid=bd1996f1d5e9434c964e662b8f8d2569',
};
