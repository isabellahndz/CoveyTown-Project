/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ViewingArea = {
    id: string;
    video?: string;
    isPlaying: boolean;
    elapsedTimeSec: number;
};

