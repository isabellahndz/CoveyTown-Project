/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Track } from './Track';

export type MusicArea = {
    id: string;
    currentTrack?: Track;
    isPlaying: boolean;
    tracks: Array<Track>;
};
