/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type CalendarEvent = {
    tracks: Array<any>;
    date: string;
    topic: string;
    id: string;
};
