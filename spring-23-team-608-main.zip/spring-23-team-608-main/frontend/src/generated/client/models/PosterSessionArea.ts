/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type PosterSessionArea = {
    id: string;
    stars: number;
    imageContents?: string;
    title?: string;
};

