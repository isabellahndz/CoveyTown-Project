import { mock, mockClear, MockProxy } from 'jest-mock-extended';
import { nanoid } from 'nanoid';
import TownController from './TownController';
import MusicAreaController, { MusicAreaEvents } from './MusicAreaController';
import { MusicArea } from '../types/CoveyTownSocket';

// describe('MusicAreaController', () => {
//   // A valid MusicAreaController to be reused within the tests
//   let testArea: MusicAreaController;
//   let testAreaModel: MusicArea;
//   const townController: MockProxy<TownController> = mock<TownController>();
//   const mockListeners = mock<MusicAreaEvents>();

//   beforeEach(() => {
//     testAreaModel = {
//       id: nanoid(),
//       isPlaying: true,
//       currentTrack: {
//         id: nanoid(),
//         name: '',
//         artist_name: '',
//         image_url: '',
//         duration_ms: 0,
//       },
//       tracks: [],
//     };
//     testArea = new MusicAreaController(testAreaModel);
//     mockClear(townController);
//     mockClear(mockListeners.playbackChange);
//     mockClear(mockListeners.trackChange);
//     testArea.addListener('playbackChange', mockListeners.playbackChange);
//     testArea.addListener('trackChange', mockListeners.trackChange);
//   });

//   describe('Setting song property', () => {
//     it('updates the property and emits a trackChange event if the property changes', () => {
//       const newTrack = {
//         id: nanoid(),
//         name: '',
//         artist_name: '',
//         image_url: '',
//         preview_url: '',
//         duration_ms: 0,
//       };
//       testArea.currentTrack = newTrack;
//       expect(mockListeners.trackChange).toBeCalledWith(newTrack);
//       expect(testArea.currentTrack).toEqual(newTrack);
//     });
//     it('does not emit a trackChange event if the track property does not change', () => {
//       testArea.currentTrack = testAreaModel.currentTrack;
//       expect(mockListeners.trackChange).not.toBeCalled();
//     });
//   });
//   describe('Setting isPlaying property', () => {
//     it('updates the model and emits a playbackChange event if the property changes', () => {
//       const newValue = !testAreaModel.isPlaying;
//       testArea.isPlaying = newValue;
//       expect(mockListeners.playbackChange).toBeCalledWith(newValue);
//       expect(testArea.isPlaying).toEqual(newValue);
//     });
//     it('does not emit a playbackChange event if the isPlaying property does not change', () => {
//       const existingValue = testAreaModel.isPlaying;
//       testArea.isPlaying = existingValue;
//       expect(mockListeners.playbackChange).not.toBeCalled();
//     });
//   });
//   describe('musicAreaModel', () => {
//     it('Carries through all of the properties', () => {
//       const model = testArea.musicAreaModel();
//       expect(model).toEqual(testAreaModel);
//     });
//   });
//   describe('updateFrom', () => {
//     it('Updates the isPlaying and song properties', () => {
//       const newModel: MusicArea = {
//         id: testAreaModel.id,
//         currentTrack: {
//           id: nanoid(),
//           name: '',
//           artist_name: '',
//           image_url: '',
//           preview_url: '',
//           duration_ms: 0,
//         },
//         tracks: [],
//         isPlaying: !testArea.isPlaying,
//       };
//       testArea.updateFrom(newModel);
//       expect(testArea.currentTrack).toEqual(newModel.currentTrack);
//       expect(testArea.isPlaying).toEqual(newModel.isPlaying);
//       expect(mockListeners.trackChange).toBeCalledWith(newModel.currentTrack);
//       expect(mockListeners.playbackChange).toBeCalledWith(newModel.isPlaying);
//     });
//     it('Does not update the id property', () => {
//       const existingID = testArea.id;
//       const newModel: MusicArea = {
//         id: nanoid(),
//         currentTrack: {
//           id: nanoid(),
//           name: '',
//           artist_name: '',
//           image_url: '',
//           preview_url: '',
//           duration_ms: 0,
//         },
//         tracks: [],
//         isPlaying: !testArea.isPlaying,
//       };
//       testArea.updateFrom(newModel);
//       expect(testArea.id).toEqual(existingID);
//     });
//   });
// });
