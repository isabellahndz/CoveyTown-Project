import { EventEmitter } from 'events';
import TypedEventEmitter from 'typed-emitter';
import { MusicArea, Track } from '../types/CoveyTownSocket';

/**
 * The events that the MusicAreaController emits to subscribers. These events
 * are only ever emitted to local components (not to the townService).
 */
export type MusicAreaEvents = {
  /**
   * A trackChange event indicates that the track selected for this music area has changed.
   * Listeners are passed the new track name, which is either a string or the value `undefined`
   * to indicate that there is no track set.
   */
  trackChange: (track: Track | undefined) => void;
  /**
   * A tracksChange event indicates that the tracks for this music area has changed.
   * Listeners are passed 'tracks changed', which is either a string or the value `undefined`
   * to indicate that there are no tracks set.
   */
  tracksChange: (message: string | undefined) => void;
  /**
   * A playbackChange event indicates that the playing/paused state has changed.
   * Listeners are passed the new state in the parameter `isPlaying`
   */
  playbackChange: (isPlaying: boolean) => void;
};

/**
 * A MusicAreaController manages the state for a MusicArea in the frontend app, serving as a bridge between the song
 * that is playing in the user's browser and the backend TownService, ensuring that all players listening to the same song
 * are synchronized in their playback.
 *
 * The MusicAreaController implements callbacks that handle events from the song player in this browser window, and
 * emits updates when the state is updated, @see MusicAreaEvents
 */
export default class MusicAreaController extends (EventEmitter as new () => TypedEventEmitter<MusicAreaEvents>) {
  private _model: MusicArea;
  /*
  /**
   * Constructs a new SongAreaController, initialized with the state of the 
   * provided musicAreaModel.
   * 
   * @param musicAreaModel The music area model that this controller should represent
   */

  constructor(musicAreaModel: MusicArea) {
    super();
    this._model = musicAreaModel;
  }

  /**
   * The ID of the music area represented by this music area controller.
   * This property is read-only: once a MusicAreaController is created, it will always be
   * tied to the same music area ID.
   */
  public get id() {
    return this._model.id;
  }

  public get currentTrack(): Track | undefined {
    return this._model.currentTrack;
  }

  public set currentTrack(track: Track | undefined) {
    if (this._model.currentTrack !== track) {
      this._model.currentTrack = track;
      this.emit('trackChange', track);
    }
  }

  public get tracks(): Track[] | undefined {
    return this._model.tracks;
  }

  public set tracks(tracks: Track[] | undefined) {
    let differentTracks = true;
    if (tracks && tracks.length == this._model.tracks.length) {
      for (let i = 0; i < tracks.length; i++) {
        differentTracks = differentTracks && this._model.tracks[i] == tracks[i];
      }
      if (differentTracks) {
        this._model.tracks = tracks;
        this.emit('tracksChange', 'Tracks changed');
      }
    } else {
      if (tracks) {
        this._model.tracks = tracks;
        this.emit('tracksChange', 'Tracks changed');
      }
    }
  }

  /**
   * The playback state - true indicating that a song is playing, false indicating
   * that the song is paused.
   */
  public get isPlaying() {
    return this._model.isPlaying;
  }

  /**
   * The playback state - true indicating that a song is playing, false indicating
   * that the song is paused.
   *
   * Changing this value will emit a 'playbackChange' event to listeners
   */
  public set isPlaying(isPlaying: boolean) {
    if (this._model.isPlaying != isPlaying) {
      this._model.isPlaying = isPlaying;
      this.emit('playbackChange', isPlaying);
    }
  }

  /**
   * @returns MusicAreaModel that represents the current state of this MusicAreaController
   */
  public musicAreaModel(): MusicArea {
    return this._model;
  }

  /**
   * Applies updates to this music area controller's model, setting the fields
   * isPlaying and song from the updatedModel
   */
  public updateFrom(updatedModel: MusicArea): void {
    this.isPlaying = updatedModel.isPlaying;
    this.currentTrack = updatedModel.currentTrack;
    this.tracks = updatedModel.tracks;
  }
}
