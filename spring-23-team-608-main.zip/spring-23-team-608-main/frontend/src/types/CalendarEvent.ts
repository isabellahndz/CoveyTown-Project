export type CalendarEvent = {
  id: string;
  topic: string;
  date: string;
  tracks: any[];
  attendees: string[];
};
