export type LeaderboardItem = {
  id: string;
  type: boolean; // 0 - track, 1 - artist
  name: string;
  votes: number;
};
