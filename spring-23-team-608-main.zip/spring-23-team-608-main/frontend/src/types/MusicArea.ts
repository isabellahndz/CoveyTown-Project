export type Artist = {
  id: string;
  name: string;
};

export type AlbumImage = {
  height: number;
  width: number;
  url: string;
};

export type Track = {
  id: string;
  name: string;
  artist_name: string;
  image_url: string;
  duration_ms: number;
  preview_url?: string;
};

export type Album = {
  id: string;
  artists: Artist[];
  name: string;
  total_tracks: number;
  images: AlbumImage[];
};
