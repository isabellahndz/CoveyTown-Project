import { ITiledMapObject } from '@jonbell/tiled-map-type-guard';
import Player from '../lib/Player';
import {
  BoundingBox,
  MusicArea as MusicAreaModel,
  TownEmitter,
  Track,
} from '../types/CoveyTownSocket';
import InteractableArea from './InteractableArea';

export default class MusicArea extends InteractableArea {
  private _currentTrack?: Track;

  private _isPlaying: boolean;

  private _tracks: Track[];

  public get currentTrack() {
    return this._currentTrack;
  }

  public get isPlaying() {
    return this._isPlaying;
  }

  public get tracks() {
    return this._tracks;
  }

  /** The conversation area is "active" when there are players inside of it  */
  public get isActive(): boolean {
    return this._occupants.length > 0;
  }

  /**
   * Creates a new MusicArea
   *
   * @param MusicAreaModel model containing this area's current topic and its ID
   * @param coordinates  the bounding box that defines this music area
   * @param townEmitter a broadcast emitter that can be used to emit updates to players
   */
  public constructor(
    { id, currentTrack, isPlaying, tracks }: MusicAreaModel,
    coordinates: BoundingBox,
    townEmitter: TownEmitter,
  ) {
    super(id, coordinates, townEmitter);
    this._currentTrack = currentTrack;
    this._isPlaying = isPlaying;
    this._tracks = tracks;
  }

  /**
   * Removes a player from this music area.
   *
   * Extends the base behavior of InteractableArea to set the topic of this MusicArea to undefined and
   * emit an update to other players in the town when the last player leaves.
   *
   * @param player
   */
  public remove(player: Player) {
    super.remove(player);
    if (this._occupants.length === 0) {
      this._currentTrack = undefined;
      this._tracks = [];
      this._emitAreaChanged();
    }
  }

  /**
   * Updates the state of the MusicArea, setting the song and isPlaying
   *
   * @param musicArea updated model
   */
  public updateModel({ isPlaying, currentTrack, tracks }: MusicAreaModel) {
    this._currentTrack = currentTrack;
    this._isPlaying = isPlaying;
    this._tracks = tracks;
  }

  /**
   * Convert this MusicArea instance to a simple MusicAreaModel suitable for
   * transporting over a socket to a client.
   */
  public toModel(): MusicAreaModel {
    return {
      id: this.id,
      currentTrack: this._currentTrack,
      isPlaying: this._isPlaying,
      tracks: this._tracks,
    };
  }

  /**
   * Creates a new MusicArea object that will represent a Music Room Area object in the town map.
   * @param mapObject An ITiledMapObject that represents a rectangle in which this music area exists
   * @param broadcastEmitter An emitter that can be used by this music area to broadcast updates
   * @returns
   */
  public static fromMapObject(
    mapObject: ITiledMapObject,
    broadcastEmitter: TownEmitter,
  ): MusicArea {
    const { name, width, height } = mapObject;
    if (!width || !height) {
      throw new Error(`Malformed viewing area ${name}`);
    }
    const rect: BoundingBox = { x: mapObject.x, y: mapObject.y, width, height };
    return new MusicArea({ id: name, isPlaying: false, tracks: [] }, rect, broadcastEmitter);
  }
}
