import { Track } from './CoveyTownSocket';

export type CalendarEvent = {
  id: string;
  topic: string;
  date: string;
  tracks: Track[];
  attendees: string[];
};
