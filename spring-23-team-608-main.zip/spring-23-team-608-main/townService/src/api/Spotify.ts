import axios from 'axios';

export type Artist = {
  id: string;
  name: string;
};

export type AlbumImage = {
  height: number;
  width: number;
  url: string;
};

export type Track = {
  id: string;
  name: string;
  artist_name: string;
  image_url: string;
  duration_ms: number;
  preview_url?: string;
};

export type Album = {
  id: string;
  artists: Artist[];
  name: string;
  total_tracks: number;
  images: AlbumImage[];
};

const spotifyAPI = {
  getTrackByName: async (name: string, accessToken: string): Promise<Track | string> => {
    const url = 'https://api.spotify.com/v1/search';
    await axios
      .get(url, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        params: {
          q: name,
          type: 'track',
        },
      })
      .then(response => {
        if (response.data && response.data.tracks && response.data.tracks.length > 0) {
          return response.data.tracks[0];
        }
        return 'Error with API response';
      })
      .catch(error => 'Error with API response');
    return 'Error';
  },
  getRecommendedTracks: async (
    seedTracks: string[],
    accessToken: string,
    limit: number,
  ): Promise<string> => {
    const url = 'https://api.spotify.com/v1/recommendations';
    const { data } = await axios.get(url, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
      },
      params: {
        seed_tracks: seedTracks.join(','),
        limit,
      },
    });

    if (data && data.tracks) {
      return data.tracks;
    }

    // throw an error
    return 'error';
  },
  getTracksByArtist: async (
    artist: string,
    accessToken: string,
    limit: number,
  ): Promise<Track[] | string> => {
    const url = 'https://api.spotify.com/v1/search';
    let artistID = '';
    await axios
      .get(url, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        params: {
          q: artist,
          type: 'artist',
        },
      })
      .then(response => {
        if (
          response.data &&
          response.data.artists &&
          response.data.artists.items &&
          response.data.artists.items.length > 0
        ) {
          artistID = response.data.artists.items[0].id || '';
        }
      })
      .catch(error => 'Error with getting Artist');

    if (artistID !== '') {
      await axios
        .get(`https://api.spotify.com/v1/artists/${artistID}/top-tracks`, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
          params: {
            limit,
            market: 'US',
          },
        })
        .then(response => {
          if (response.data && response.data.tracks && response.data.tracks.length > 0) {
            const tracks: Track[] = [];
            for (let i = 0; i < response.data.tracks.length; i++) {
              if (response.data.tracks[i] && response.data.tracks[i].preview_url) {
                tracks.push(response.data.tracks[i]);
              }
            }
            return tracks;
          }
          return 'Error with getting tracks';
        })
        .catch(error => 'Error with getting tracks');
    }
    return 'Error with getting Artist';
  },
  getTracksByAlbum: async (
    albumName: string,
    accessToken: string,
    limit: number,
  ): Promise<Track[] | string> => {
    const url = 'https://api.spotify.com/v1/search';
    let albumID = '';
    await axios
      .get(url, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        params: {
          q: albumName,
          type: 'album',
        },
      })
      .then(response => {
        if (
          response.data &&
          response.data.albums &&
          response.data.albums.items &&
          response.data.albums.items.length > 0
        ) {
          albumID = response.data.albums.items[0].id || '';
        }
      })
      .catch(error => 'Error with getting Album');

    if (albumID !== '') {
      await axios
        .get(`https://api.spotify.com/v1/albums/${albumID}/tracks`, {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
          params: {
            limit,
            market: 'US',
          },
        })
        .then(response => {
          if (response.data && response.data.items && response.data.items.length > 0) {
            const tracks: Track[] = [];
            for (let i = 0; i < response.data.items.length; i++) {
              if (response.data.items[i] && response.data.items[i].preview_url) {
                tracks.push(response.data.items[i]);
              }
            }
            return tracks;
          }
          return 'Error with getting tracks';
        })
        .catch(error => 'Error with getting tracks');
    }
    return 'Error with getting Album';
  },
};

export default spotifyAPI;
